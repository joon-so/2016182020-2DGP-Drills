data = {"x": 10, "y":20, "size":1.5}
file = open('data.txt', 'w')
file.write(str(data))
file.close()
