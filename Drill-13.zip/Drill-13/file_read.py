file = open('data.txt', 'r')
data_str = file.read()
file.close()
print(data_str)


